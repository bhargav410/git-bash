#!/bin/bash

a=123
b=456
c="this is devops"

echo "################################"

echo $a
echo
echo $b
echo
echo $c

echo "####################"

echo "quations"
echo
echo "value of a is $a"
echo
echo 'printing exact value $a'
echo "escaping the interpiting valu"
echo
echo "without variable value \$a"
