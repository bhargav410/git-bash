#!/bin/bash

# this is echo script

echo "hi devops, this is my first script"
