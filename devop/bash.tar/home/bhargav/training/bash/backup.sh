#!/bin/bash

echo "hellow"
tar -cvf /home/bhargav/training/bash.tar /home/bhargav/training/bash
gzip /home/bhargav/training/bash.tar
