#!/bin/bash

#making directort

mkdir $1

#making files into directory

touch $1/$2
