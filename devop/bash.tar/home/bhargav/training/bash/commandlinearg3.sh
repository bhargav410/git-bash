#!/bin/bash

#giving permission to present file

chmod u+x $1

#details of file
ls -lh $1
