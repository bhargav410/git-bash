#!/bin/bash
# printing values through command line interface
echo "command line arguiments"
echo

cp $1 $2

echo "checking files in $2"

ls -lh $2
